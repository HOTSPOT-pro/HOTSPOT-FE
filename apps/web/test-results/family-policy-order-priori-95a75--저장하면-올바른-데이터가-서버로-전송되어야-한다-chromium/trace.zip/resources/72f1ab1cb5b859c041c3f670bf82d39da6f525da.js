(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f2313fc6._.css",
  "static/chunks/_2ad0d699._.js",
  "static/chunks/0179a_next_80815c7a._.js",
  "static/chunks/a94f9_tailwind-merge_dist_bundle-mjs_mjs_f110c13e._.js",
  "static/chunks/61c74_recharts_es6_state_800b0f7b._.js",
  "static/chunks/61c74_recharts_es6_util_8deaca12._.js",
  "static/chunks/61c74_recharts_es6_component_80c505c1._.js",
  "static/chunks/61c74_recharts_es6_cartesian_00369a11._.js",
  "static/chunks/61c74_recharts_es6_4de8b0d8._.js",
  "static/chunks/5ed5c_react-hook-form_dist_index_esm_mjs_405f8b12._.js",
  "static/chunks/f2b82_@tanstack_query-core_build_modern_30e0d66b._.js",
  "static/chunks/6c32e_axios_lib_43ea9415._.js",
  "static/chunks/node_modules__pnpm_e8feef4b._.js"
],
    source: "dynamic"
});
