(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7ec6ca11._.js",
  "static/chunks/0179a_next_dist_compiled_react-dom_f1890597._.js",
  "static/chunks/0179a_next_dist_compiled_react-server-dom-turbopack_ea239d76._.js",
  "static/chunks/0179a_next_dist_compiled_next-devtools_index_46bbe56b.js",
  "static/chunks/0179a_next_dist_compiled_ffa8ab32._.js",
  "static/chunks/0179a_next_dist_client_77e15dc4._.js",
  "static/chunks/0179a_next_dist_009dbe0d._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
